library(lmmm)
buildModel()
